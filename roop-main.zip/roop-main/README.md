------
title: Insightswap
emoji: 🤘
colorFrom: gray
colorTo: gray
sdk: gradio
sdk_version: 3.41.2
app_file: app.py
pinned: false
license: openrail
-----
